 % This code calculates the voltage phasors and system frequecy 
 
Fs=1e4; tao=1/Fs; Fo=60; wo=2*pi*Fo;
%Read the file with the VT measuments from PowerFacotory.
datapt=csvread('C:\WAPS_Simulator\MEDPT.csv',2,0);    
t=datapt(:,1)'; %Extracts the time vector from PowerFactory.   
tact(iter,1)=t(end);
 
Pt=39; %Number of VT installed in the system.
   %Discret Fourier Transform
    sp=datapt(:,2:(3*Pt+1));             
    Lp=length(sp); Nmp=166;
    Up=[0:Nmp-1]; Ap=Up'*Up;
    Wp=exp(2*pi*1i*(Ap/Nmp)); 
    PT=inv(Wp)*sp(1:Nmp,:); 
    
    PT1mag=abs(PT*2);Modf=ones(166,1)*PT1mag(2,:);
    PT1ang=angle(PT*2); Angf=ones(166,1)*PT1ang(2,:);
    modulo_kPT=Modf(end,:);angulo_kPT=Angf(end,:);
    
    %Volatge phasors database 
    modulo_kPTR(iter,:)=Modf(end,:);
    angulo_kPTR(iter,:)=Angf(end,:);
    fasor_kPT(iter,:)=(modulo_kPT.*exp(i*angulo_kPT))';
      
   %Positive Component Sequence Calculation
   cp=1;fasorposp=fasor_kPT(end,:);
   for p=1:Pt
       PTpos(iter,p)=sum(fasorposp(cp:cp+2).*apos);
       cp=cp+3;
   end   
   PTpos2(iter,:)=fasorposp(1:3:(3*Pt-2))*apos(1)+fasorposp(2:3:(3*Pt-1))*apos(2)+fasorposp(3:3:3*Pt)*apos(3);
   
   %TimeStamp (UTC) 
    tempoV1ar(iter)=datetime('now','TimeZone','local','Format','d-MMM-y HH:mm:ss');
    datehour(iter)=datetime('now','Format','HH:mm:ss');
    tempoV1ar.TimeZone='America/Bogota';
    TV1arUTC(iter)=posixtime(tempoV1ar(iter));
    
    %Frequency Stimation
   if iter>2
delta1(iter,:)=angle(PTpos(iter-1,:));
delta2(iter,:)=angle(PTpos(iter,:));
deltad(iter,:)=delta1(iter,:)-delta2(iter,:);

for fq=1:Pt
    if deltad(iter,Pt)>pi
      deltad(iter,Pt)=deltad(iter,Pt)-2*pi;
    end
    if deltad(iter,Pt)<-pi
      deltad(iter,Pt)=deltad(iter,Pt)+2*pi;
    end
end

deltawr(iter,:)=deltad(iter,:)/(2*pi)+1;
deltawr(iter,:)=(deltawr(iter,:)<1)+deltawr(iter,:);
deltafq(iter,:)=deltawr(iter,:)/0.020;
freq(iter,:)=deltafq(iter,:);

%Average System Frequency
freq_prom(iter,1)=sum(freq(iter,:))/39;

UFLS_WAP;
freq_prom(1:4)=60;
GUI_WAP;
   end
   
pause(0.002);