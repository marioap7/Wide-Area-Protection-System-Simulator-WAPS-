%Wide-Area Protection System Simulator 
%Execute this file only.

clear memory; close all; clear all; clc;
opengl software

%Define initial values and write/read files
iter=0; c1=1; c2=1; c3=1; c4=1; c5=1; c6=1; 
csvwrite('freq.txt',[60; iter]);
EDAC1=0; EDAC2=0; EDAC3=0; EDAC4=0; EDAC5=0; EDAC6=0;
fi2=fopen('EDAC.txt', 'w');
fprintf(fi2, '%i %i %i %i %i %i',EDAC1, EDAC2, EDAC3, EDAC4, EDAC5, EDAC6);
fclose(fi2);

%Component sequence constants
a=1*exp(1i*((2*pi)/3)); T=[1 1 1; 1 a a^2;1 a^2 a];apos=[1 a^2 a]/3;

%conmu.txt is the flag file between Matlab and PowerFactory
ed1=1;fi=fopen('conmu.txt', 'w');
fprintf(fi, '%f',0); fclose(fi);

fileID = fopen('conmu.txt','r'); formatSpec = '%f';
ctlmd = fscanf(fileID,formatSpec); fclose(fileID); 
 
for nfor=1:10000
iter=nfor;

fileID = fopen('conmu.txt','r'); formatSpec = '%f';
ctlmd = fscanf(fileID,formatSpec); fclose(fileID);
pause(0.025)

while ctlmd==0 % If the value is 0 is because PowerFactory is executing his routine and Matlab waits 
        
      for o=1:500; 
      display('Execute DIgSILENT script');   
      end
      
   fileID3 = fopen('conmu.txt','r');
      formatSpec = '%f';
      ctlmd = fscanf(fileID3,formatSpec);
      fclose(fileID3);
      
      if ctlmd==1 % PowerFactory finished the routine
      break
      end
end

if ctlmd==1 % If the value is 1 Matbal executes the routine and PowerFactory waits
   DFT_WAP;
   
   fileID2=fopen('conmu.txt', 'w');
   fprintf(fileID2, '%f',0);
   fclose(fileID2);
end  
end



