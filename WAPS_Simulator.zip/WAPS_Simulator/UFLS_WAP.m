%This code executes the Drive Logic for the Automatic Load Shedding Scheme

if freq_prom(iter)<59.4
  et1(c1)=tact(iter);
   if c1>2
       edc1=et1(c1)-et1(c1-2); 
      if edc1>0.039 & edc1<0.041
          EDAC1=1;
      end
   end
   c1=c1+1; 
end
  
     
if freq_prom(iter)<59.2 & EDAC1==1
   et2(c2)=tact(iter);
   if c2>2
       edc2=et2(c2)-et2(c2-2);
       if edc2>0.039 & edc2<0.041
           EDAC1=0;
           EDAC2=1;
       end
   end
   c2=c2+1;
end

 
if freq_prom(iter)<59 & EDAC2==1
   et3(c3)=tact(iter);
   if c3>3
       edc3=et3(c3)-et3(c3-3);
       if edc3>0.059 & edc3<0.061
           EDAC2=0;
           EDAC3=1;
       end
   end
   c3=c3+1;
end

if freq_prom(iter)<58.8 & EDAC3==1
   et4(c4)=tact(iter);
   if c4>3
       edc4=et4(c4)-et4(c4-3);
       if edc4>0.059 & edc4<0.061
           EDAC3=0;
           EDAC4=1;
       end
   end
   c4=c4+1;
end

if freq_prom(iter)<58.6 & EDAC4==1
   et5(c5)=tact(iter);
   if c5>4
       edc5=et5(c5)-et5(c5-4);
       if edc5>0.079 & edc5<0.081
           EDAC4=0;
           EDAC5=1;
       end
   end
   c5=c5+1;
end


if freq_prom(iter)<58.4 & EDAC5==1
   et6(c6)=tact(iter);
   if c6>4
       edc6=et6(c6)-et6(c6-4);
       if edc6>0.079 & edc6<0.081
           EDAC5=0;
           EDAC6=1;
       end
   end
   c6=c6+1;
end

%Write the UFLS steps state in a txt file. 
fi2=fopen('EDAC.txt', 'w');
fprintf(fi2, '%i %i %i %i %i %i',EDAC1, EDAC2, EDAC3, EDAC4, EDAC5, EDAC6);
fclose(fi2);
